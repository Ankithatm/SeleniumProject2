package EcapProject2;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeMethod;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;

public class LoginFailed {
	WebDriver driver;
  @Test
  public void invalidUserLogin() throws InterruptedException, IOException {
	  
	  driver.get("https://www.saucedemo.com/");
	  driver.manage().window().maximize();
	  
	  FileReader reader=new FileReader("C:\\Users\\Ankitha TM\\eclipse-workspace\\EcapProject\\src\\test\\java\\EcapProject2\\DataInputs.properties");
		Properties props=new Properties();
		props.load(reader);
	 
	  driver.findElement(By.xpath("//input[@id='user-name']")).sendKeys(props.getProperty("username"));
	 
		Thread.sleep(2000);
	 driver.findElement(By.xpath("//input[@id='password']")).sendKeys(props.getProperty("password"));
	 
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//input[@id='login-button']")).click();
		
		Thread.sleep(2000);
	    System.out.println("Epic sadface: Username and password do not match any user in this service");
	    
  }
  @BeforeMethod
  public void launchBrowser() {
	  WebDriverManager.chromedriver().setup();
	  driver=new ChromeDriver();
	  
  }

  @AfterMethod
  public void closeBrowser(){
	  driver.close();
  }

}
