package EcapProject2;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class SortItem {
	WebDriver driver;
	  @Test
	  public void remove() throws IOException, InterruptedException {
		  
		  driver.get("https://www.saucedemo.com/");
		  driver.manage().window().maximize();
		  
		  FileReader reader=new FileReader("C:\\Users\\Ankitha TM\\eclipse-workspace\\EcapProject\\src\\test\\java\\EcapProject2\\DataInputs.properties");
			Properties props=new Properties();
			props.load(reader);
		 
		  driver.findElement(By.xpath("//input[@id='user-name']")).sendKeys(props.getProperty("userName"));
		 
			Thread.sleep(2000);
		 driver.findElement(By.xpath("//input[@id='password']")).sendKeys(props.getProperty("password"));
		 
			Thread.sleep(2000);
			
			driver.findElement(By.xpath("//input[@id='login-button']")).click();
			
		WebElement sort=driver.findElement(By.xpath("//select[@class='product_sort_container']"));
			
			Select s=new Select(sort);
			
		  s.selectByValue("az");
		
		 
		 System.out.println("Items are sorted in Name (A to Z) order");
			
				
			
}
	  @BeforeMethod
	  public void launchBrowser() {
	  	  
	  	  WebDriverManager.chromedriver().setup();
	  	  driver=new ChromeDriver();
	  	  
	  	  
	    }

	    @AfterMethod
	    public void closeBrowser() {
	  	  driver.close();
	    }
}
